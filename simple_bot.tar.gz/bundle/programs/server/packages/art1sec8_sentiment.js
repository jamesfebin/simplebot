(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;

/* Package-scope variables */
var sentiment;

(function(){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// packages/art1sec8_sentiment/packages/art1sec8_sentiment.js              //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/art1sec8:sentiment/sentiment-server.js                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/*jshint -W020*/                                                     // 1
sentiment = Npm.require('sentiment');                                // 2
/*jshint +W020*/                                                     // 3
                                                                     // 4
                                                                     // 5
Meteor.methods({                                                     // 6
  sentiment: function ( str, obj ) {                                 // 7
    check(str, String);                                              // 8
    if (obj) {                                                       // 9
      check(obj, Object);                                            // 10
    }                                                                // 11
    return sentiment( str, obj );                                    // 12
  }                                                                  // 13
});                                                                  // 14
///////////////////////////////////////////////////////////////////////

}).call(this);

/////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['art1sec8:sentiment'] = {}, {
  sentiment: sentiment
});

})();
