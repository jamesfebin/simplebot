var require = meteorInstall({"server":{"main.js":["meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var Meteor = void 0;                                                 // 1
module.import('meteor/meteor', {                                     // 1
    "Meteor": function (v) {                                         // 1
        Meteor = v;                                                  // 1
    }                                                                // 1
}, 0);                                                               // 1
Meteor.startup(function () {// code to run on server at startup      // 3
});                                                                  // 5
Meteor.methods({                                                     // 7
    'sendText': function (text) {                                    // 8
        console.log(text);                                           // 9
    }                                                                // 10
});                                                                  // 7
///////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
